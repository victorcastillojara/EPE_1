/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Conexion.Conectar;
/**
 *
 * @author carlos
 */
public class Clientec extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Conectar sql=new Conectar();
        
        String nombre=request.getParameter("nombre");
        String apellido=request.getParameter("apellido");
        String direccion=request.getParameter("direccion");
        int edad=Integer.parseInt(request.getParameter("edad"));
        String rut=request.getParameter("rut");
        String sexo=request.getParameter("sexo");
        
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>"
                    + "<meta charset=\"utf-8\">\n" +
"        <link rel=\"icon\" type=\"image/png\" href=\"img/favicon.png\" />\n" +
"	<link rel=\"stylesheet\" href=\"estilo.css\">\n" +
"	<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css\">\n" +
"	<script src=\"https://code.jquery.com/jquery-3.3.1.slim.min.js\"></script>\n" +
"<script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js\"></script>\n" +
"<script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js\"></script>");
            out.println("<title>..::Inicio::..</title>");       
            out.println("</head>");
            out.println("<body background=\"img/fondo2.jpg\">\n" +
"	<div id=\"cabecera\" align=\"center\" style=\"font-family: Impact, Haettenschweiler, 'Franklin Gothic Bold', 'Arial Black', 'sans-serif'\">\n" +
"	<header>\n" +
"            <h1 style=\"color: white;\">Vicali Motor</h1>\n" +
"	</header>\n" +
"	</div>\n" +
"	\n" +
"<div id=\"menu\"> \n" +
"    <nav class=\"navbar navbar-expand-lg navbar navbar-dark bg-dark\">\n" +
"        <a class=\"navbar-brand\" href=\"Cliente.jsp\" style=\"font-family: Birds of Paradise;\">Vicali Motor's</a>\n" +
"  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">\n" +
"    <span class=\"navbar-toggler-icon\"></span>\n" +
"  </button>\n" +
"\n" +
"  <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">\n" +
"    <ul class=\"navbar-nav mr-auto\">\n" +
"      <li class=\"nav-item active\">\n" +
"        <a class=\"nav-link\" href=\"Cliente.jsp\">Inicio <span class=\"sr-only\">(current)</span></a>\n" +
"      </li>\n" +
"      <li class=\"nav-item\">\n" +
"        <a class=\"nav-link\" href=\"Arriendos.jsp\">Arriendos</a>\n" +
"      </li>\n" +
"      <li class=\"nav-item dropdown\">\n" +
"        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">\n" +
"          Registro\n" +
"        </a>\n" +
"        <div class=\"dropdown-menu\" aria-labelledby=\"navbarDropdown\">\n" +
"          <a class=\"dropdown-item\" href=\"Cliente.jsp\">Clientes</a>\n" +
"          <a class=\"dropdown-item\" href=\"Arriendos.jsp\">Ariendos</a>\n" +
"          <div class=\"dropdown-divider\"></div>\n" +
"          <a class=\"dropdown-item\" href=\"Vendedores.jsp\">vendedores</a>\n" +
"        </div>\n" +
"      </li>\n" +
"    </ul>\n" +
"    \n" +
"  </div>\n" +
"</nav>\n" +
"        </div>\n" +
"      </nav>\n" +
"</div>\n" +
"	\n" +
"<div style=\"width: 125px; border: 1px ; float: left; clear: left;\" class=\"table-dark\">\n" +
"	<aside>\n" +
"		<ul class=\"nav flex-column\">\n" +
"  <li class=\"nav-item\">\n" +
"    <a class=\"nav-link active\" href=\"ListaC.jsp\">Lista clientes</a>\n" +
"  </li>\n" +
"  <li class=\"nav-item\">\n" +
"    <a class=\"nav-link\" href=\"ListaA.jsp\">Lista arriendos</a>\n" +
"  </li>\n" +
"  <li class=\"nav-item\">\n" +
"    <a class=\"nav-link\" href=\"ListaV.jsp\">Lista vendedores</a>\n" +
"  </li>\n" +
"</ul>\n" +
"	</aside>\n" +
"	</div>");
            out.println("<h1>" + sql.ingresarCliente(nombre, apellido, direccion, edad, rut, sexo)+ "</h1>");
            out.println("<div id=\"pie\">\n" +
"	<footer>\n" +
"	</footer>\n" +
"	</div>"
                    + "</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
