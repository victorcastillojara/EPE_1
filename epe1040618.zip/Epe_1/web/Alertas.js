function Inicio(){
        alert("Inicio de sesion correcto");
}

function Registro(){
    alert("Registro Exitoso");
}