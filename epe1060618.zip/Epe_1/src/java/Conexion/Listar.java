/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Chronos
 */
public class Listar {
    
        Connection conexion=null;
        Statement sentencia=null;
        ResultSet resultados = null;
        String BD="RentaCar";
        String url="jdbc:postgresql://localhost:5433/"+BD;
        String usuario="postgres";
        String pass="1234";
        Conectar realizar;
        
    public List a=new ArrayList();
    public List b=new ArrayList();
    public List c=new ArrayList();
    public List d=new ArrayList();
    public List e=new ArrayList();
    public List f=new ArrayList();
    public List g=new ArrayList();
    public List h=new ArrayList();
    public List i=new ArrayList();
    
    //------MOSTRAR--------
    public String recuperarCliente(){
        a.clear();
        b.clear();
        c.clear();
        d.clear();
        e.clear();
        f.clear();
        g.clear();
        Connection conexion=null;
        Statement sentencia=null;
        String nombreBD="RentaCar";
        String url="jdbc:postgresql://localhost:5433/"+nombreBD;
        String usuario="postgres";
        String password="1234";
        ResultSet resultados=null;
        try{
          Class.forName("org.postgresql.Driver");
          conexion = DriverManager.getConnection(url, usuario, password);
          sentencia = conexion.createStatement();
          String sql = "select * from cliente";
          resultados=sentencia.executeQuery(sql);
          while(resultados.next()){
                int id=resultados.getInt("id");
                String nombres=resultados.getString("nombre");
                String apellidos=resultados.getString("apellido");
                String direccion=resultados.getString("direccion");
                String edad=resultados.getString("edad");
                String rut=resultados.getString("rut");
                String sexo=resultados.getString("sexo");
                
                a.add(id);
                b.add(nombres);
                c.add(apellidos);
                d.add(direccion);
                e.add(edad);
                f.add(rut);
                g.add(sexo);
                
          }
          sentencia.close();
          conexion.close();
                    
        }catch(Exception e){
          return "Error!"+ e.getMessage();
        }
        return "Datos capturados!!";
    }
    
    public String recuperarArriendos(){
        a.clear();
        b.clear();
        c.clear();
        d.clear();
        e.clear();
        f.clear();
        g.clear();
        Connection conexion=null;
        Statement sentencia=null;
        String nombreBD="RentaCar";
        String url="jdbc:postgresql://localhost:5433/"+nombreBD;
        String usuario="postgres";
        String password="1234";
        ResultSet resultados=null;
        try{
          Class.forName("org.postgresql.Driver");
          conexion = DriverManager.getConnection(url, usuario, password);
          sentencia = conexion.createStatement();
          String sql = "select * from arriendos";
          resultados=sentencia.executeQuery(sql);
          while(resultados.next()){
                int id=resultados.getInt("id");
                String vehiculo=resultados.getString("vehiculo");
                String marca=resultados.getString("marca");
                String fechaarriendo=resultados.getString("fechaarriendo");
                String fechaentrega=resultados.getString("fechaentrega");
                String valor=resultados.getString("valor");
                String seguro=resultados.getString("seguro");
                
                a.add(id);
                b.add(vehiculo);
                c.add(marca);
                d.add(fechaarriendo);
                e.add(fechaentrega);
                f.add(valor);
                g.add(seguro);
                
          }
          sentencia.close();
          conexion.close();
                    
        }catch(Exception e){
          return "Error!"+ e.getMessage();
        }
        return "Datos capturados!!";
    }
        public String recuperarEjecutivos(){
        a.clear();
        b.clear();
        c.clear();
        d.clear();
        e.clear();
        f.clear();
        g.clear();
        h.clear();
        i.clear();
        Connection conexion=null;
        Statement sentencia=null;
        String nombreBD="RentaCar";
        String url="jdbc:postgresql://localhost:5433/"+nombreBD;
        String usuario="postgres";
        String password="1234";
        ResultSet resultados=null;
        try{
          Class.forName("org.postgresql.Driver");
          conexion = DriverManager.getConnection(url, usuario, password);
          sentencia = conexion.createStatement();
          String sql = "select * from ejecutivo";
          resultados=sentencia.executeQuery(sql);
          while(resultados.next()){
                int id=resultados.getInt("id");
                String nombre=resultados.getString("nombre");
                String apellido=resultados.getString("apellido");
                String cargo=resultados.getString("cargo");
                String edad=resultados.getString("edad");
                String rut=resultados.getString("rut");
                String sexo=resultados.getString("sexo");
                String nomusuario=resultados.getString("nomusuario");
                String contraseña=resultados.getString("contraseña");
                
                a.add(id);
                b.add(nombre);
                c.add(apellido);
                d.add(cargo);
                e.add(edad);
                f.add(rut);
                g.add(sexo);
                h.add(nomusuario);
                i.add(contraseña);
                
          }
          sentencia.close();
          conexion.close();
                    
        }catch(Exception e){
          return "Error!"+ e.getMessage();
        }
        return "Datos capturados!!";
    }
        
        
        
        public String recuperarArriendos1(){
        a.clear();
        b.clear();
        c.clear();
        d.clear();
        e.clear();
        f.clear();
        g.clear();
        Connection conexion=null;
        Statement sentencia=null;
        String nombreBD="RentaCar";
        String url="jdbc:postgresql://localhost:5433/"+nombreBD;
        String usuario="postgres";
        String password="1234";
        ResultSet resultados=null;
        try{
          Class.forName("org.postgresql.Driver");
          conexion = DriverManager.getConnection(url, usuario, password);
          sentencia = conexion.createStatement();
          String sql = "select a.id,vehiculo,marca,fechaarriendo,fechaentrega,c.nombre,apellido from arriendos as a join cliente as c on a.id=c.id";
          resultados=sentencia.executeQuery(sql);
          while(resultados.next()){
                int id=resultados.getInt("id");
                String nombre=resultados.getString("nombre");
                String apellido=resultados.getString("apellido");
                String vehiculo=resultados.getString("vehiculo");
                String marca=resultados.getString("marca");
                String fechaA=resultados.getString("fechaarriendo");
                String fechaE=resultados.getString("fechaentrega");
                
                a.add(id);
                b.add(nombre);
                c.add(apellido);
                d.add(vehiculo);
                e.add(marca);
                f.add(fechaA);
                g.add(fechaE);
                
          }
          sentencia.close();
          conexion.close();
                    
        }catch(Exception e){
          return "Error!"+ e.getMessage();
        }
        return "Datos capturados!!";
    }
    
}
