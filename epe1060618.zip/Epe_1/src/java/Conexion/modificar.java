/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author linkpipe
 */
public class modificar {
    
     Connection conexion=null;
        Statement sentencia=null;
        ResultSet resultados = null;
        String BD="RentaCar";
        String url="jdbc:postgresql://localhost:5433/"+BD;
        String usuario="postgres";
        String pass="1234";
        
        public String modificarC(String id, String columna,String cambio){
            int id1=Integer.parseInt(id);
            try{
                
          Class.forName("org.postgresql.Driver");
          conexion = DriverManager.getConnection(url, usuario, pass);
          sentencia = conexion.createStatement();
          String sql = "UPDATE cliente SET "+columna+"='"+cambio+"' WHERE id='"+id1+"'";
          sentencia.executeUpdate(sql);
          sentencia.close();
          conexion.close();
                
            }catch(ClassNotFoundException | SQLException e){
                System.out.println("Error "+e);
            }
            return null;
        }   
        public String modificarV(String id, String columna,String cambio){
            int id1=Integer.parseInt(id);
            try{
                
          Class.forName("org.postgresql.Driver");
          conexion = DriverManager.getConnection(url, usuario, pass);
          sentencia = conexion.createStatement();
          String sql = "UPDATE ejecutivo SET "+columna+"='"+cambio+"' WHERE id='"+id1+"'";
          sentencia.executeUpdate(sql);
          sentencia.close();
          conexion.close();
                
            }catch(ClassNotFoundException | SQLException e){
                System.out.println("Error "+e);
            }
            return null;
        }   
        public String modificarA(String id, String columna,String cambio){
            int id1=Integer.parseInt(id);
            try{
                
          Class.forName("org.postgresql.Driver");
          conexion = DriverManager.getConnection(url, usuario, pass);
          sentencia = conexion.createStatement();
          String sql = "UPDATE arriendos SET "+columna+"='"+cambio+"' WHERE id='"+id1+"'";
          sentencia.executeUpdate(sql);
          sentencia.close();
          conexion.close();
                
            }catch(ClassNotFoundException | SQLException e){
                System.out.println("Error "+e);
            }
            return null;
        }   
        
}
