function Inicio(f){
    if (f.user.value   == '' && f.pass.value == '') { 
           alert ('Los campos estan vacios'); 
           f.user.focus(); 
return false; }
       if (f.user.value   == '') { 
           alert ('El nombre esta vacío'); 
           f.user.focus(); 
return false; }
if (f.pass.value  == '') { 
    alert ('El password esta vacío');
f.pass.focus(); 
return false; } 
return true; 
}

function Registro(){
    alert("Registro Exitoso");
}